package com.example.switching.connector.service;

import java.util.Locale;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.example.switching.connector.dto.ConnectorConfigResponse;
import com.example.switching.connector.dto.CreateConnectorConfigRequest;
import com.example.switching.connector.dto.UpdateConnectorConfigRequest;
import com.example.switching.connector.entity.ConnectorConfigEntity;
import com.example.switching.connector.enums.ConnectorType;
import com.example.switching.connector.exception.ConnectorConfigAlreadyExistsException;
import com.example.switching.connector.exception.ConnectorConfigNotFoundException;
import com.example.switching.connector.repository.ConnectorConfigRepository;
import com.example.switching.participant.service.ParticipantService;

@Service
public class ConnectorConfigManagementService {

    private final ConnectorConfigRepository connectorConfigRepository;
    private final ParticipantService participantService;

    public ConnectorConfigManagementService(ConnectorConfigRepository connectorConfigRepository,
                                            ParticipantService participantService) {
        this.connectorConfigRepository = connectorConfigRepository;
        this.participantService = participantService;
    }

    @Transactional
    public ConnectorConfigResponse create(CreateConnectorConfigRequest request) {
        requireField(request.getConnectorName(), "connectorName");
        requireField(request.getBankCode(), "bankCode");
        requireField(request.getConnectorType(), "connectorType");

        String connectorName = request.getConnectorName().trim().toUpperCase(Locale.ROOT);
        String bankCode = request.getBankCode().trim().toUpperCase(Locale.ROOT);
        ConnectorType connectorType = parseConnectorType(request.getConnectorType());

        if (connectorConfigRepository.findByConnectorName(connectorName).isPresent()) {
            throw new ConnectorConfigAlreadyExistsException(connectorName);
        }

        // Validate bank exists in participants
        participantService.findByBankCode(bankCode);

        ConnectorConfigEntity entity = new ConnectorConfigEntity();
        entity.setConnectorName(connectorName);
        entity.setBankCode(bankCode);
        entity.setConnectorType(connectorType);
        entity.setEndpointUrl(request.getEndpointUrl());
        entity.setTimeoutMs(request.getTimeoutMs() != null ? request.getTimeoutMs() : 5000);
        entity.setEnabled(request.getEnabled() != null ? request.getEnabled() : true);
        entity.setForceReject(request.getForceReject() != null ? request.getForceReject() : false);
        entity.setRejectReasonCode(request.getRejectReasonCode());
        entity.setRejectReasonMessage(request.getRejectReasonMessage());

        connectorConfigRepository.save(entity);
        return ConnectorConfigResponse.from(entity);
    }

    @Transactional
    public ConnectorConfigResponse update(String connectorName, UpdateConnectorConfigRequest request) {
        String normalizedName = connectorName.trim().toUpperCase(Locale.ROOT);

        ConnectorConfigEntity entity = connectorConfigRepository.findByConnectorName(normalizedName)
                .orElseThrow(() -> new ConnectorConfigNotFoundException(normalizedName));

        if (request.getEndpointUrl() != null) {
            entity.setEndpointUrl(StringUtils.hasText(request.getEndpointUrl())
                    ? request.getEndpointUrl().trim()
                    : null);
        }
        if (request.getTimeoutMs() != null) {
            entity.setTimeoutMs(request.getTimeoutMs());
        }
        if (request.getEnabled() != null) {
            entity.setEnabled(request.getEnabled());
        }
        if (request.getForceReject() != null) {
            entity.setForceReject(request.getForceReject());
        }
        if (request.getRejectReasonCode() != null) {
            entity.setRejectReasonCode(StringUtils.hasText(request.getRejectReasonCode())
                    ? request.getRejectReasonCode().trim()
                    : null);
        }
        if (request.getRejectReasonMessage() != null) {
            entity.setRejectReasonMessage(StringUtils.hasText(request.getRejectReasonMessage())
                    ? request.getRejectReasonMessage().trim()
                    : null);
        }

        connectorConfigRepository.save(entity);
        return ConnectorConfigResponse.from(entity);
    }

    private ConnectorType parseConnectorType(String raw) {
        try {
            return ConnectorType.valueOf(raw.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException(
                    "Invalid connectorType: " + raw + ". Valid values: MOCK, HTTP, MQ");
        }
    }

    private void requireField(String value, String fieldName) {
        if (!StringUtils.hasText(value)) {
            throw new IllegalArgumentException(fieldName + " is required");
        }
    }
}

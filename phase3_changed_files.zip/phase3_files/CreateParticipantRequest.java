package com.example.switching.participant.dto;

public class CreateParticipantRequest {

    private String bankCode;
    private String bankName;
    private String status;           // ACTIVE | INACTIVE | MAINTENANCE (default ACTIVE)
    private String participantType;  // BANK | FINTECH | NBFI (default BANK)
    private String country;
    private String currency;

    public String getBankCode() { return bankCode; }
    public void setBankCode(String bankCode) { this.bankCode = bankCode; }

    public String getBankName() { return bankName; }
    public void setBankName(String bankName) { this.bankName = bankName; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getParticipantType() { return participantType; }
    public void setParticipantType(String participantType) { this.participantType = participantType; }

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
}

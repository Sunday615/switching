package com.example.switching.routing.service;

import java.util.Locale;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.example.switching.iso.enums.IsoMessageType;
import com.example.switching.participant.service.ParticipantService;
import com.example.switching.routing.dto.CreateRoutingRuleRequest;
import com.example.switching.routing.dto.RoutingRuleResponse;
import com.example.switching.routing.dto.UpdateRoutingRuleRequest;
import com.example.switching.routing.entity.RoutingRuleEntity;
import com.example.switching.routing.exception.RoutingRuleAlreadyExistsException;
import com.example.switching.routing.exception.RoutingRuleNotFoundException;
import com.example.switching.routing.repository.RoutingRuleRepository;

@Service
public class RoutingRuleManagementService {

    private final RoutingRuleRepository routingRuleRepository;
    private final ParticipantService participantService;
    private final RoutingService routingService;

    public RoutingRuleManagementService(RoutingRuleRepository routingRuleRepository,
                                        ParticipantService participantService,
                                        RoutingService routingService) {
        this.routingRuleRepository = routingRuleRepository;
        this.participantService = participantService;
        this.routingService = routingService;
    }

    @Transactional
    public RoutingRuleResponse create(CreateRoutingRuleRequest request) {
        requireField(request.getRouteCode(), "routeCode");
        requireField(request.getSourceBank(), "sourceBank");
        requireField(request.getDestinationBank(), "destinationBank");
        requireField(request.getMessageType(), "messageType");
        requireField(request.getConnectorName(), "connectorName");

        String routeCode = request.getRouteCode().trim().toUpperCase(Locale.ROOT);
        String sourceBank = request.getSourceBank().trim().toUpperCase(Locale.ROOT);
        String destinationBank = request.getDestinationBank().trim().toUpperCase(Locale.ROOT);
        String connectorName = request.getConnectorName().trim().toUpperCase(Locale.ROOT);
        IsoMessageType messageType = parseMessageType(request.getMessageType());

        if (routingRuleRepository.findByRouteCode(routeCode).isPresent()) {
            throw new RoutingRuleAlreadyExistsException(routeCode);
        }

        // Validate source and destination banks exist in participants table
        participantService.findByBankCode(sourceBank);
        participantService.findByBankCode(destinationBank);

        RoutingRuleEntity entity = new RoutingRuleEntity();
        entity.setRouteCode(routeCode);
        entity.setSourceBank(sourceBank);
        entity.setDestinationBank(destinationBank);
        entity.setMessageType(messageType);
        entity.setConnectorName(connectorName);
        entity.setPriority(request.getPriority() != null ? request.getPriority() : 1);
        entity.setEnabled(request.getEnabled() != null ? request.getEnabled() : true);

        routingRuleRepository.save(entity);

        // Clear routing cache so new rule is picked up immediately
        routingService.clearCache();

        return RoutingRuleResponse.from(entity);
    }

    @Transactional
    public RoutingRuleResponse update(String routeCode, UpdateRoutingRuleRequest request) {
        String normalizedCode = routeCode.trim().toUpperCase(Locale.ROOT);

        RoutingRuleEntity entity = routingRuleRepository.findByRouteCode(normalizedCode)
                .orElseThrow(() -> new RoutingRuleNotFoundException(normalizedCode, "-", "-"));

        if (StringUtils.hasText(request.getConnectorName())) {
            entity.setConnectorName(request.getConnectorName().trim().toUpperCase(Locale.ROOT));
        }
        if (request.getPriority() != null) {
            entity.setPriority(request.getPriority());
        }
        if (request.getEnabled() != null) {
            entity.setEnabled(request.getEnabled());
        }

        routingRuleRepository.save(entity);

        // Clear routing cache so change takes effect immediately
        routingService.clearCache();

        return RoutingRuleResponse.from(entity);
    }

    private IsoMessageType parseMessageType(String raw) {
        try {
            return IsoMessageType.valueOf(raw.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException(
                    "Invalid messageType: " + raw + ". Valid values: PACS_008, PACS_002, PACS_028, PACS_004");
        }
    }

    private void requireField(String value, String fieldName) {
        if (!StringUtils.hasText(value)) {
            throw new IllegalArgumentException(fieldName + " is required");
        }
    }
}
